<?php
/**
 * @package Make
 */

/**
 * Interface MAKE_Customizer_PreviewInterface
 *
 * @since 1.7.0.
 */
interface MAKE_Customizer_PreviewInterface extends MAKE_Util_ModulesInterface {}