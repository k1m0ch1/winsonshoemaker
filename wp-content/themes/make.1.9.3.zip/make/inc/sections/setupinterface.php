<?php
/**
 * @package Make
 */


interface MAKE_Sections_SetupInterface extends MAKE_Util_ModulesInterface {}