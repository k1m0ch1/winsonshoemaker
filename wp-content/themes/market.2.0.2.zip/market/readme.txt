Thank you for Using Market Wordpress Theme. For any other help please visit http://wordpress.org/support/theme/market/

	i) Market WordPress Theme is Based on the Underscores Framework http://underscores.me/, (C) 2012-2014 Automattic, Inc. 
	ii) Market has been created Rohit Tripathi. You can Follow me on http://twitter.com/rohitinked/
	iii) It comes GNU General Public License. More Details about the License can be found in the license.txt file included in the theme.
	
## Copyrights for Resources used in this theme.
	i) Market Uses Elements from the Bootstrap Framework, which is under the Apache v2 license.
	ii) Font-Awesome Icons are under the MIT Licnese.
	iii) This theme uses nivoSlider, which is under the MIT License. More details: 
	        http://nivo.dev7studios.com
	   		http://www.opensource.org/licenses/mit-license.php
	iv) For the Administration Panel, we have used "Options Framework", which is under GPL v2 license. http://wptheming.com/options-framework-theme/
	v) The files options-custom.js, and media-uploader.js present in the "/js" Folder are part of the "Options Framework", and are under GPL v2.
	vi) custom.js has been created by me and under GPL v3.
	vii) skip-link-focus-fix.js, customizer.js & keyboard-image-navigation.js are part of the Underscores Framework used by the theme, and hence under GPL v3.
	viii) The Reponsive Menu plugin, mm.js is under GPL v3. https://github.com/rohitink/Responsive-Menu/
	ix) The images nthumb, dthumb, divider.png have been created by me for the purpose of this theme. 2cl and 2cr are part of Options framework and are under GPL license.
	x) The files in the css/ folder are a part of nivoSlider and under MIT license.
	xi) The Screenshot has been created using GPL Images taken from Pixabay.com and Unsplash.com
	
Screenshot & Default Images
---------------------------

All These Images are under Public Domain, CC0 License. No Copyrights.

License URI -> http://creativecommons.org/publicdomain/zero/1.0/

i) http://pixabay.com/static/uploads/photo/2014/07/25/08/48/sunset-401541_150.jpg
ii) http://pixabay.com/static/uploads/photo/2014/07/10/10/20/golden-gate-bridge-388917_150.jpg
iii) http://pixabay.com/static/uploads/photo/2014/08/11/11/05/oriental-pearl-tower-415474_150.jpg
iv) http://pixabay.com/static/uploads/photo/2014/07/01/12/37/lifeguard-381240_150.jpg
v) http://pixabay.com/static/uploads/photo/2014/07/01/12/35/taxi-cab-381233_150.jpg
vi) http://pixabay.com/static/uploads/photo/2014/07/01/12/36/smartphone-381237_150.jpg
vii) http://pixabay.com/en/photographer-tourist-snapshot-407068/
viii) http://pixabay.com/en/milsons-point-sydney-australia-330400/
ix) http://unsplash.com/post/94204091269/download-by-elaine-li
x) http://pixabay.com/en/manhattan-new-york-city-407703/
	
Everything else used in this theme has been created by me, especially for Market theme and is distributed under GPL license.
		
	For any help you can mail me at rohit[at]rohitink.com