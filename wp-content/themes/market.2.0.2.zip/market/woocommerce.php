<?php

get_header(); ?>

	<div id="primary-shop" class="content-area col-md-8">
		<main id="main" class="site-main" role="main">

			<?php woocommerce_content(); ?>
			
		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>